//
//  SendNotification.swift
//  FcmNotificationServer
//
//  Created by Giwoo Kim on 5/25/24.
//
import Foundation
import JWTKit

///Users/giwookim/Desktop/fcmNotificationServer/FcmNotificationServer/croaksproject-firebase-adminsdk-anwwd-6c29af4c4d.json

var filePath1 = "/Users/giwookim/Desktop/fcmNotificationServer/FcmNotificationServer/croaksproject-firebase-adminsdk-anwwd-6c29af4c4d.json"
var filePath2 = "/Users/giwookim/Desktop/fcmNotificationServer/FcmNotificationServer/croaksproject-997da8feb0b8.json"

struct  MyPayload: JWTPayload {
    func verify(using signer: JWTKit.JWTSigner) throws {
      
    }
    
    let iss: String // 발급자
    let scope: String // 스코프
    let aud: String // 대상자
    let exp: Int // 만료 시간
    let iat: Int // 발급 시간
}

class SendNotification{
  
    var accessToken : String = ""
   
    
    var fcmToken : String =   "e8P_2D-wxkUUuHM3FnwSRV:APA91bFDm7rrxBT3v3Xmxt35iel0FMg499m8GShowwS7-UZgmuAbZuWz9lEP0Pie2nFwnNK2lQ8oPCFadLYyvf23Ak4xy86DK3KNBOptWmn0yIlnRiOfwTMXeGirn_n4_tZVHHIsHHl7"
    
    func getAccessToken(serviceAccountFile: String, completion: @escaping (String?) -> Void) {
        guard let serviceAccountURL = Bundle.main.url(forResource: serviceAccountFile, withExtension:  nil),
              let keyData = try? Data(contentsOf: serviceAccountURL),
              let keyJSON = try? JSONSerialization.jsonObject(with: keyData, options: []) as? [String: Any],
              let clientEmail = keyJSON["client_email"] as? String,
              let privateKey = keyJSON["private_key"] as? String,
              let privateKeyId = keyJSON["private_key_id"] as? String else {
            
            print("Error reading service account key file.")
            completion(nil)
            return
        }
        // JWT 클레임 구성
        let tokenURI = "https://oauth2.googleapis.com/token"
        let scope = "https://www.googleapis.com/auth/firebase.messaging"
        let currentTime = Int(Date().timeIntervalSince1970)
        let expiryTime = currentTime + 3600 * 1// 1시간 유효
        
        let payload  = MyPayload(iss: clientEmail, scope: scope, aud: tokenURI, exp: expiryTime, iat: currentTime)
        
        
        
        
        do {
            // JWT 서명자 생성 및 JWT 서명
            let signer = try JWTSigner.rs256(key: .private(pem: privateKey.data(using: .utf8)!))
            let jwt = try signer.sign(payload, kid: JWKIdentifier(string: privateKeyId))
            //  print("JWT: \(jwt)")
            
            // URLSession을 사용하여 액세스 토큰 요청
            var request = URLRequest(url: URL(string: tokenURI)!)
            request.httpMethod = "POST"
            request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            
            let requestBody = "grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=\(jwt)"
            request.httpBody = requestBody.data(using: .utf8)
            
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                guard let data = data, error == nil else {
                    print("Error: \(String(describing: error))")
                    completion(nil)
                    return
                }
                
                do {
                    // JSON 응답에서 액세스 토큰 추출
                    if let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                       let accessToken = jsonResponse["access_token"] as? String {
                        //  print("jsonResponse :  \(jsonResponse)")
                        print("accessToked is acquired")
                        completion(accessToken)
                    } else {
                        print("Error: Access token not found in response")
                        completion(nil)
                    }
                } catch {
                    print("Error: \(error.localizedDescription)")
                    completion(nil)
                }
            }
            
            task.resume()
        } catch {
            print("Error: \(error.localizedDescription)")
            completion(nil)
        }
        
    }
    
    func sendNotification() {
        sendPushNotification()
    }
    
    func sendPushNotification() {
        let url = URL(string: "https://fcm.googleapis.com/v1/projects/croaksproject/messages:send")!
        var request = URLRequest(url: url)
        
        //        var accessToken =  "ya29.c.c0AY_VpZhlsD7yMm8Mf0bIK1OHST96RfTECYPLQzquRPs1VU9bTV1Jcu3cywxV7I0O70xGrx6OrOjY2vommcH0ZxhBG9tDPMG_Je3yF2jJPNvu6KqzPCx_vat8NTDwQ4Txq3vqt0-0JnH2akzajurghVeVgvtRrsTHm4JYasZsa_upNNNPidpHcWwdcS8tUBtIm0OdSdhTWw7khBHyuYm3XrWg36oNDQeyhXihdLxvwHuIW5pvZ3bB2VobIQHaKZEb6Tor62N1LQd_L6eo_xgq7Ri0lPBRImxCiOyIv2NkhvXb1DWjhPUWuIAhpcY9P1ZPcjva6TgSQT-qywiE5FHpVkeuzwcOQScA8mJK3cu_VOMXsQVCygKRb2EUG385A6mquycMczveohvu2WF-8nw2txf8xXa1ctlVbqtv0kWVxFsrh-RhbYfq8tys70gmeJgpYmh2aU1-bUljQS7M067aF04urbSz0Xahuu9SV58er1B93hzcO_Sg6bJ23a__2e8x-mdZFVs6FwUIuf1RlIYcn1SY1BhoM4pU0aYb_y2k2n6_y2oQZligxi09ucU3qshtB9onzJY1QX5hMzQ8wwm8-eZz1k0mSqw9M3owVaYh-XMhkp09roaqgoZXOY6qqlY5oYxbybwRQyehqo104F_OQg17-lfc-9yr-hkIJ6lcO1bqhnmsZIYxJcydV7S6o4Z8YpJS0_5hY1vYlfQu5IjYSRf_maMRxfZZVJgi9FQB79ododw3FpjUzoqgFw3W2u76Su1U5XdV2uRUqpyylVf1mg8ez2hfkIyv0z8hdrkIntwUrc7OmR40ufrMSQppjOblt6tMa6-l1YpWf2UsOUBzfVlcrXSxirORSpkiWjsswoVMUuhpIuaVobtQktRRsf7m0eU2_0twZMpe1YR01XiFYZ9M-Uyr79JBzyez3Qf0kMec8nvIlXvMFr9Jf30vBq6VgIF4MBRkm7bJaqpWbvOzBs1vhJlqj_Ru2ybnvIXdQZB3zScdfsofOJ2"
        
        let fcmToken = "e8P_2D-wxkUUuHM3FnwSRV:APA91bFDm7rrxBT3v3Xmxt35iel0FMg499m8GShowwS7-UZgmuAbZuWz9lEP0Pie2nFwnNK2lQ8oPCFadLYyvf23Ak4xy86DK3KNBOptWmn0yIlnRiOfwTMXeGirn_n4_tZVHHIsHHl7"
        
        let jsonFile  = "croaksproject-firebase-adminsdk-anwwd-6c29af4c4d.json"
        
        getAccessToken(serviceAccountFile: "croaksproject-997da8feb0b8.json") {
            token in
            if let token = token {
                self.accessToken = token
                print("accessToken from getAccessToken:\n")
                //  print(self.accessToken)
                
            } else {
                print("token is lost")
                return
            }
            
/*         background
           The push type for notifications that deliver content in the background, and don’t trigger any user interactions. If you set this push type, the apns-topic header field must use your app’s bundle ID as the topic. Always use priority 5. Using priority 10 is an error. For more information, see Pushing background updates to your App.
            You’re required to use the background push type on watchOS 6 and later. It’s recommended on macOS, iOS, tvOS, and iPadOS.

 To send a background notification, create a remote notification with an aps dictionary that includes only the content-available key, as shown in the sample code below. You may include custom keys in the payload, but the aps dictionary must not contain any keys that would trigger user interactions.
 {
    "aps" : {
       "content-available" : 1
    },
    "acme1" : "bar",
    "acme2" : 42
 }


 Additionally, the notification’s POST request should contain the apns-push-type header field with a value of background, and the apns-priority field with a value of 5. The APNs server requires the apns-push-type field when sending push notifications to Apple Watch, and recommends it for all platforms. For more information, see Create a POST request to APNs in Sending notification requests to APNs.
*/
            let headers = [
                "Content-Type": "application/json",
                "Authorization": "Bearer \(self.accessToken)",

            ]
           
            
            request.httpMethod = "POST"
            request.allHTTPHeaderFields = headers
            // 메세지만 되거나 데이타만 되거나
            //둘다 넣게 되면 아직까지 에러... 둘다 넣으면 백그라운드에서 깨어나긴 할까???
            
            let parameters: [String: Any] = [
                "message": [
                    "token": fcmToken,
                    "notification": [
                        "title": "Hi Croaks~~",
                        "body": "Good Morning  From FCMNotificationServer~"
                    ]
                ]
            ]
//            
//            {
//              "message":{
//                 "token":"bk3RNwTe3H0:CI2k_HHwgIpoDKCIZvvDMExUdFQ3P1...",
//                 "notification":{
//                   "title":"Match update",
//                   "body":"Arsenal goal in added time, score is now 3-0"
//                 },
//                 "android":{
//                   "ttl":"86400s",
//                   "notification"{
//                     "click_action":"OPEN_ACTIVITY_1"
//                   }
//                 },
//                 "apns": {
//                   "headers": {
//                     "apns-priority": "5",
//                   },
//                   "payload": {
//                     "aps": {
//                       "category": "NEW_MESSAGE_CATEGORY"
//                     }
//                   }
//                 },
//                 "webpush":{
//                   "headers":{
//                     "TTL":"86400"
//                   }
//                 }
//               }
//             }
        
            
            // headers parameters
            
            request.allHTTPHeaderFields = headers
            // From Foundation Object TO JSONDATA
            request.httpBody = try? JSONSerialization.data(withJSONObject: parameters)
            print("HTTP Method: \(request.httpMethod ?? "No Method Specified")")
//          print("HTTP Headers: \(request.allHTTPHeaderFields ?? [:])")
            // Data -> JsonObject <- > FoundationObject <-> .data -------------> String
            //Jsondata    -------->      array, dictionar   ------->  Jsondata
            if let bodyData = request.httpBody, let bodyString = String(data: bodyData, encoding: .utf8) {
              //  print("HTTP Body: \(bodyString)")
                print("BodyData of parm0 is loaded")
            } else {
                print("No HTTP Body")
            }
            
            
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                guard let data = data, error == nil else {
                    print("Error:", error?.localizedDescription ?? "Unknown error")
                    return
                }
                if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                    print("HTTP 상태 코드:", httpStatus.statusCode)
             
                    return
                }
                let responseString = String(data: data, encoding: .utf8)
                print("응답 데이터: param ..이것은 그냥 일반적인 메세지 테스트 ", responseString ?? "")
            
            }
            task.resume()
            
            sleep(5)
            
            // headers2 parameters2
            
            let headers2 = [
                "Content-Type": "application/json",
                "Authorization": "Bearer \(self.accessToken)",
                "apns-push-type" : "background",
                "apns-priority" : "5",
                "apns-topic" : "com.giwoo.andy.fcmNotificationServer"
            ]
            let parameters2: [String: Any] = [
                "message" : [
                    "token": fcmToken,
                   
                    "apns": [
                        "payload": [
                            "aps": [
                               
                                "content-available": 1
                            ]
                        ]
                    ]
                ]
                
            ]
            
            
            request.httpMethod = "POST"
            request.allHTTPHeaderFields = headers2
            request.httpBody = try? JSONSerialization.data(withJSONObject: parameters2)
            print("HTTP Method: \(request.httpMethod ?? "No Method Specified")")
            print("HTTP Headers: \(request.allHTTPHeaderFields ?? [:])")
            if let bodyData = request.httpBody, let bodyString = String(data: bodyData, encoding: .utf8) {
                print("HTTP Body: \(bodyString)")
                print("BodyData param2 is loaded")
            } else {
                print("No HTTP Body")
            }
            
            
            let task2 = URLSession.shared.dataTask(with: request) { data, response, error in
                guard let data = data, error == nil else {
                    print("Error:", error?.localizedDescription ?? "Unknown error")
                    return
                }
                print(data.debugDescription)
                if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                    print("HTTP 상태 코드:", httpStatus.statusCode)
                    print(httpStatus)
                    return
                }
                let responseString = String(data: data, encoding: .utf8)
                print("응답 데이터:param2 백그라운드에서 크록이 깨워져야 하는데...", responseString ?? "")
            }
            task2.resume()
        }
    }
    
    // 나중에 테스트.. 이렇게 안해도 됨
    func createJWT(clientEmail: String, scope: String, tokenURI: String, expiryTime: Int, currentTime: Int) -> String? {
        // JWT 페이로드 생성
        let payload = MyPayload(iss: clientEmail, scope: scope, aud: tokenURI, exp: expiryTime, iat: currentTime)

        // JWT 페이로드를 JSON 문자열로 변환
        guard let payloadData = try? JSONEncoder().encode(payload) else {
            return nil
        }
        let payloadString = String(data: payloadData, encoding: .utf8)!

        // JWT 페이로드를 Base64로 인코딩
        let payloadBase64 = payloadString.toBase64()

        // JWT 생성
        let jwt = payloadBase64

        return jwt
    }

   
}

extension String {
    func toBase64() -> String {
        return Data(self.utf8).base64EncodedString()
    }
}


// 예제 사용법
//let serviceAccountKeyPath = "path/to/your/service-account-file.json"
//getAccessToken(from: serviceAccountKeyPath) { accessToken in
//    if let token = accessToken {
//        print("Access Token: \(token)")
//        // 이 액세스 토큰을 사용하여 Firebase FCM API 요청을 수행합니다.
//    } else {
//        print("Failed to get access token.")
//    }
//}

