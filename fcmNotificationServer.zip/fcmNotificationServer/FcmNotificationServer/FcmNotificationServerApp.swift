//
//  fcmNotificationServerApp.swift
//  fcmNotificationServer
//
//  Created by Giwoo Kim on 5/25/24.
//

import SwiftUI

@main
struct fcmNotificationServerApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
