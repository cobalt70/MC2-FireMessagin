//
//  ContentView.swift
//  fcmNotificationServer
//
//  Created by Giwoo Kim on 5/25/24.
//

import SwiftUI

struct ContentView: View {
    var sendNotificaiton =  SendNotification()
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
            
            Button(action: {
                let notifier = SendNotification()
                notifier.sendPushNotification()
            }) {
                Label("Send Remote MSG", systemImage: "plus")
            }
        }
        
        .padding()
    }
}

#Preview {
    ContentView()
}
